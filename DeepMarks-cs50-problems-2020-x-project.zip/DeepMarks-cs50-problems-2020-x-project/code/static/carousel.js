$('.carousel').carousel({
  interval: 1000
})