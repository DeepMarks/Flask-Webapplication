import camelot
import csv
import requests

url = "https://racketlon.ch/images/stories/2020/2020.02.01_SRNT_Altstätten_Resultate.pdf"

r = requests.get(url,timeout=1)
try:
    r.raise_for_status()
except:
    pass
if r.status_code == 200:
    # readinf the PDF file that contain Table Data
    # you can find find the pdf file with complete code in below
    # read_pdf will save the pdf table into Pandas Dataframe
    table = camelot.read_pdf(url)
    table[0].to_csv("tournament.csv")